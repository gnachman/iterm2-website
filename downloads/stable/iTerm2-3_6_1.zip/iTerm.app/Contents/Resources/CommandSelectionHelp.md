## Command Selection

When you click on a command in a terminal, it becomes “selected”. iTerm2 draws selected commands with an outline and dims non-selected commands. Some features, like Search and Filter, then operate only on the selected command. 

You can disable this feature with “Disable Command Selection” in the settings menu from which you opened this Help window. If you’d like to re-enable it later, search app Settings for “Clicking: on a command selects it.”
