(function() {
    if (window.iTermReaderMode) {
        return window.iTermReaderMode.exit();
    }
    return false;
})()