(function() {
    if (window.iTermDistractionRemoval) {
        return window.iTermDistractionRemoval.enter();
    }
    return false;
})()