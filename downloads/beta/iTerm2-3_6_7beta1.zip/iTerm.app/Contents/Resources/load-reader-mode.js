// Load reader mode functionality directly
{{READER_MODE_JS}}

// Return true to indicate successful loading
true